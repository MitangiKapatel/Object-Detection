# Kaggle-dog-and-cat-dataset
Kaggle dog and cat classification  
download VGG16_weight.npy  
  
  https://mega.nz/#!YU1FWJrA!O1ywiCS2IiOlUCtCpI6HTJOMrneN-Qdv3ywQP5poecM  
  
Dog_cat dataset  
  
  https://www.kaggle.com/c/dogs-vs-cats#description 
    
